import argparse
import json
import os
from pathlib import Path
import subprocess

OUT = Path('/evidence')
parser = argparse.ArgumentParser()
parser.add_argument('--phase',choices=['discover','capture'],required=True)
parser.add_argument('--plan',default='capture-plan.json')
args = parser.parse_args()

def run(command,name,timeout=120):
    result = subprocess.run(command,capture_output=True,text=True,timeout=timeout)
    (OUT/(name+'.log')).write_text(result.stdout+result.stderr)
    (OUT/(name+'.command.json')).write_text(json.dumps(command,indent=2)+'\n')
    (OUT/(name+'.exit')).write_text(str(result.returncode)+'\n')
    print(name,'exit',result.returncode,flush=True)
    return result

if args.phase == 'discover':
    import torch
    torch.cuda.set_device(0)
    prop = torch.cuda.get_device_properties(0)
    assert prop.gcnArchName.split(':')[0]=='gfx1200'
    uuid = bytes.fromhex(str(prop.uuid).replace('-','')).decode('ascii')
    assert uuid==os.environ['BENCH_HIP_UUID']
    (OUT/'device.json').write_text(json.dumps({'name':prop.name,'arch':prop.gcnArchName,'uuid':uuid,
                                             'torch':torch.__version__,'hip':torch.version.hip},indent=2)+'\n')
    for command,name in [(['rocprofv3','--version'],'version'),
                         (['rocprofv3','--list-avail'],'counters'),
                         (['rocprofv3-avail','list','--help'],'avail-list'),
                         (['rocprofv3-avail','info','--help'],'avail-info'),
                         (['rocprofv3-avail','pmc-check','--help'],'pmc-check')]:
        run(command,name)
    llvm = Path('/usr/local/lib/python3.14/dist-packages/_rocm_sdk_devel/lib/llvm/bin')
    (OUT/'llvm-tools.json').write_text(json.dumps([str(x) for x in llvm.iterdir() if x.name in
                  ('llvm-objdump','llvm-readelf','llvm-readobj','llvm-objcopy','clang++')],indent=2)+'\n')
    torch.cuda.synchronize()
else:
    os.environ['PYTHONPATH'] = '/candidate:/workspace/.venv/lib/python3.14/site-packages:/scripts'
    plan = json.loads((Path('/scripts')/args.plan).read_text())
    failures = []
    for job in plan:
        dest = OUT/job['name']; dest.mkdir(exist_ok=True)
        cmd = ['rocprofv3',*job['profiler_args'],'-d',str(dest),'-o','profile',
               '--','python3','/scripts/workload.py','--sid',str(job['sid']),
               '--layout',job['layout'],'--out',str(dest),'--repeats',str(job.get('repeats',3))]
        result = run(cmd,job['name'],timeout=job.get('timeout',180))
        if result.returncode:
            failures.append({'name':job['name'],'returncode':result.returncode})
            if job.get('required',True): break
    (OUT/'job-failures.json').write_text(json.dumps(failures,indent=2)+'\n')
    if failures: raise SystemExit(1)
