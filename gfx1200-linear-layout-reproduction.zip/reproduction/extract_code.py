"""Extract the gfx1200 ELF from clang's offload bundle, without recompilation."""
import json
from pathlib import Path
import struct
import subprocess
import sys

def extract(binary, output):
    magic = b'__CLANG_OFFLOAD_BUNDLE__'
    entries = []
    if binary.startswith(magic):
        pos = len(magic)
        count, = struct.unpack_from('<Q',binary,pos); pos += 8
        assert 0 < count < 32
        for _ in range(count):
            offset,size,length = struct.unpack_from('<QQQ',binary,pos); pos += 24
            target = binary[pos:pos+length].decode(); pos += length
            entries.append({'target':target,'offset':offset,'size':size})
        selected = [x for x in entries if 'gfx1200' in x['target']]
        assert len(selected)==1
        item = selected[0]
        assert item['offset']+item['size']<=len(binary)
        elf = binary[item['offset']:item['offset']+item['size']]
    else:
        elf = binary
    assert elf.startswith(b'\x7fELF')
    output.mkdir(parents=True,exist_ok=True)
    (output/'kernel.hsaco').write_bytes(elf)
    (output/'offload-bundle.json').write_text(json.dumps(entries,indent=2)+'\n')
    llvm = Path('/usr/local/lib/python3.14/dist-packages/_rocm_sdk_devel/lib/llvm/bin')
    for command,name in [([str(llvm/'llvm-objdump'),'-d','--mcpu=gfx1200',str(output/'kernel.hsaco')],'isa.txt'),
                         ([str(llvm/'llvm-readelf'),'--notes',str(output/'kernel.hsaco')],'metadata.txt')]:
        result = subprocess.run(command,capture_output=True,text=True,check=True)
        (output/name).write_text(result.stdout+result.stderr)
    return entries

if __name__ == '__main__':
    print(extract(Path(sys.argv[1]).read_bytes(),Path(sys.argv[2])))
