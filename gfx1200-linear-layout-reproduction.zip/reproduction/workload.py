"""Profile the exact benchmark kernel after correctness plus ten warmups."""
import argparse
import os
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import time

import numpy as np
import torch
import tilelang
from tilelang.contrib import hipcc
from kernel_factory import factory
from extract_code import extract

parser = argparse.ArgumentParser()
parser.add_argument('--sid',type=int,required=True)
parser.add_argument('--layout',choices=['default','linear'],required=True)
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--repeats',type=int,default=3)
args = parser.parse_args()
OUT = args.out
SHAPES = [(4096,1024,8192),(4096,8192,8192),(4096,28672,8192),(4096,8192,28672),
          (8192,1024,8192),(8192,8192,8192),(8192,28672,8192),(8192,8192,28672)]
torch.cuda.set_device(0)
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
prop = torch.cuda.get_device_properties(0)
uuid = bytes.fromhex(str(prop.uuid).replace('-','')).decode('ascii')
assert torch.cuda.device_count()==1 and prop.gcnArchName.split(':')[0]=='gfx1200'
assert uuid==os.environ['BENCH_HIP_UUID']
hip = ctypes.CDLL('/usr/local/lib/python3.14/dist-packages/_rocm_sdk_core/lib/libamdhip64.so.7')
bus = ctypes.create_string_buffer(32)
assert hip.hipDeviceGetPCIBusId(bus,len(bus),0)==0 and bus.value.decode().lower()==os.environ['BENCH_BDF'].lower()
M,N,K = SHAPES[args.sid]
original_compile = hipcc.compile_hip
def capture_compile(*positional,**kwargs):
    binary = original_compile(*positional,**kwargs)
    (OUT/'kernel.bundle').write_bytes(bytes(binary))
    (OUT/'compiler-arguments.json').write_text(json.dumps(kwargs,indent=2)+'\n')
    return binary
hipcc.compile_hip = capture_compile
kernel = tilelang.compile(factory(M,N,K,args.layout=='linear'),
                          target={'kind':'hip','mcpu':'gfx1200'},execution_backend='tvm_ffi')
source = kernel.get_kernel_source()
(OUT/'kernel.hip').write_text(source)
extract((OUT/'kernel.bundle').read_bytes(),OUT)
rng = np.random.default_rng(20261101+args.sid)
ac = rng.integers(-2,3,size=(M,K),dtype=np.int8)
bc = rng.integers(-2,3,size=(K,N),dtype=np.int8)
hashes = {name:hashlib.sha256(value).hexdigest() for name,value in [('a_int8_sha256',ac),('b_int8_sha256',bc)]}
a = torch.from_numpy(ac).to(device='cuda',dtype=torch.bfloat16)
b = torch.from_numpy(bc).to(device='cuda',dtype=torch.bfloat16)
del ac,bc
guard = torch.full((M*N+32,),123,device='cuda',dtype=torch.bfloat16)
c = guard[16:-16].view(M,N)
expected = (a.float()@b.float()).to(torch.bfloat16)
kernel(a,b,c)  # main_kernel iteration 1
torch.cuda.synchronize()
torch.testing.assert_close(c,expected,rtol=0,atol=0)
del expected
for _ in range(10): kernel(a,b,c)  # main_kernel iterations 2–11
torch.cuda.synchronize()
cache = torch.empty(256*1024*1024//4,device='cuda',dtype=torch.int32)
start = time.time()
for _ in range(args.repeats):
    cache.zero_()
    torch.cuda.synchronize()
    kernel(a,b,c)  # profiler filters iterations 12–14, ATT only 12
    torch.cuda.synchronize()
assert bool(torch.all(guard[:16]==123)&torch.all(guard[-16:]==123))
receipt = {'sid':args.sid,'shape':[M,N,K],'layout':args.layout,'uuid':uuid,'bdf':bus.value.decode(),
           'correctness_passed':True,'guards_passed':True,'input_hashes':hashes,
           'kernel_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
           'hsaco_sha256':hashlib.sha256((OUT/'kernel.hsaco').read_bytes()).hexdigest(),
           'profiled_iterations_requested':list(range(12,12+args.repeats)),
           'start_unix':start,'end_unix':time.time()}
(OUT/'workload.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
