"""CPU-only launcher regression tests; Docker, GPU telemetry and policy are fakes."""
import contextlib
import fcntl
import importlib.util
import io
import itertools
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='tilelang-launcher-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        source = Path(__file__).with_name('run.py')
        spec = importlib.util.spec_from_file_location('launcher_under_test', source)
        self.launcher = importlib.util.module_from_spec(spec)
        argv = [str(source), '--config', str(source.with_name('config.example.json')),
                '--out', str(self.root/'out'), '--mode', 'bench']
        with patch.object(sys, 'argv', argv):
            spec.loader.exec_module(self.launcher)
        m = self.launcher
        m.OUT.mkdir(parents=True)
        self.lock_dir = self.root/'locks'
        self.lock_dir.mkdir()
        m.LOCK_DIR = self.lock_dir
        m.RECOVERY_MARKER = self.lock_dir/'recovery-required.json'
        self.calls = []
        self.policies = []
        self.stopped = threading.Event()
        self.monitor = None
        self.fail_stop = False
        self.fail_inspect = False
        self.fail_restore = False
        self.fail_initial_policy = False
        self.fail_receipt = False
        self.stop_timeout_but_exited = False
        self.inspect_missing = False
        self.inspect_permission_denied = False
        self.busy = False
        self.client_stuck = False
        self.container_running = False
        self.policy = 'auto'
        self.process = SimpleNamespace(running=True, returncode=None)

        def poll():
            return None if self.process.running else self.process.returncode

        def wait(timeout):
            if self.process.running:
                raise subprocess.TimeoutExpired('docker run', timeout)
            return self.process.returncode

        def end_client():
            self.calls.append('client-terminate')
            if not self.client_stuck:
                self.process.running = False
                self.process.returncode = -15

        self.process.poll = poll
        self.process.wait = wait
        self.process.terminate = end_client
        self.process.kill = end_client

        def popen(*args, **kwargs):
            self.calls.append('launch')
            self.container_running = self.process.running
            return self.process

        def docker(command, **kwargs):
            op = command[1:3]
            self.calls.append(tuple(op))
            if op[0] == 'stop':
                if self.fail_stop:
                    if self.stop_timeout_but_exited:
                        self.container_running = False
                    raise subprocess.TimeoutExpired(command, 30)
                self.container_running = False
                self.process.running = False
                self.process.returncode = 0
            elif op == ['container', 'inspect']:
                if self.fail_inspect:
                    raise subprocess.TimeoutExpired(command, 10)
                if self.inspect_permission_denied:
                    return subprocess.CompletedProcess(command, 1, '', 'permission denied')
                if self.inspect_missing:
                    return subprocess.CompletedProcess(command, 1, '',
                                                       f'Error: No such container: {m.CONTAINER}')
                state = {'Running': self.container_running, 'Restarting': False,
                         'Status': 'running' if self.container_running else 'exited'}
                return subprocess.CompletedProcess(command, 0, json.dumps(state), '')
            elif op[0] == 'kill':
                self.container_running = False
            else:
                raise AssertionError(command)
            return subprocess.CompletedProcess(command, 0, '', '')

        def set_policy(value):
            self.policies.append(value)
            if value == 'STABLE_PEAK' and self.fail_initial_policy:
                raise RuntimeError('injected initial setter failure')
            if value == 'AUTO':
                self.assertFalse(self.container_running, 'AUTO before container exit')
                self.assertFalse(self.busy, 'AUTO before GPU drain')
                if self.fail_restore:
                    raise RuntimeError('injected AUTO failure')
            self.policy = 'profile_peak' if value == 'STABLE_PEAK' else 'auto'

        def telemetry():
            return {'kfd_pids': ['123'] if self.busy and 'launch' in self.calls else [],
                    'performance_level': self.policy, 'runtime_status': 'active'}

        def metric(label):
            return {'perf_level': 'AMDSMI_DEV_PERF_LEVEL_' +
                    ('STABLE_PEAK' if self.policy == 'profile_peak' else 'AUTO')}

        class Monitor:
            def __init__(inner, **kwargs):
                inner.alive = False
                inner.daemon = kwargs.get('daemon', False)
                self.monitor = inner

            def start(inner): inner.alive = True
            def join(inner, timeout): inner.alive = not self.stopped.is_set()
            def is_alive(inner): return inner.alive

        # Real flock operations are confined to temporary files, even for the
        # original launcher whose lock paths were hard-coded.
        def open_local(path, flags, *args):
            if str(path).startswith('/run/lock/'):
                path = self.lock_dir/Path(path).name
            return os.open(path, flags, *args)

        m.os = SimpleNamespace(open=open_local, close=os.close, fdopen=os.fdopen,
                               fsync=os.fsync, path=os.path, O_CREAT=os.O_CREAT,
                               O_RDWR=os.O_RDWR, O_WRONLY=os.O_WRONLY,
                               O_EXCL=os.O_EXCL, O_NOFOLLOW=os.O_NOFOLLOW,
                               getpid=os.getpid)
        m.subprocess = SimpleNamespace(Popen=popen, run=docker, STDOUT=subprocess.STDOUT,
                                       TimeoutExpired=subprocess.TimeoutExpired)
        def thread_factory(**kwargs):
            return threading.Thread(**kwargs) if kwargs.get('name') == 'gpu-recovery-probe' else Monitor(**kwargs)

        m.threading = SimpleNamespace(Event=lambda: self.stopped, Thread=thread_factory)
        ticks = itertools.count(0, 1801)
        m.time = SimpleNamespace(time=time.time, monotonic=lambda: next(ticks), sleep=lambda _: None)
        m.set_policy, m.metric, m.telemetry = set_policy, metric, telemetry
        m.container_command = lambda: ['docker', 'run', 'fake']
        self.saved_signal_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
        self.addCleanup(lambda: [signal.signal(sig, handler) for sig, handler in self.saved_signal_handlers.items()])
        original_save = m.save

        def save(name, data):
            if self.fail_receipt and name == 'lifecycle.json' and 'ended_unix' in data:
                raise OSError('injected receipt write failure')
            original_save(name, data)

        m.save = save

    def run_main(self):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            try:
                self.launcher.main()
            except Exception as error:
                return error
            finally:
                for sig, handler in self.saved_signal_handlers.items():
                    self.assertEqual(signal.getsignal(sig), handler)
                for lock in self.lock_dir.glob('*.lock'):
                    with lock.open('r+') as handle:
                        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return None

    def receipt(self):
        return json.loads((self.launcher.OUT/'lifecycle.json').read_text())

    def test_stop_timeout_still_shuts_monitor_and_recovers(self):
        self.fail_stop = True
        error = self.run_main()
        self.assertTrue(self.stopped.is_set())
        self.assertFalse(self.monitor.is_alive())
        self.assertTrue(self.monitor.daemon)
        self.assertEqual(self.policies, ['STABLE_PEAK', 'AUTO'])
        self.assertIsInstance(error, TimeoutError)
        self.assertTrue(self.receipt()['recovery_verified'])
        self.assertFalse(self.launcher.RECOVERY_MARKER.exists())
        self.assertIn(('kill', self.launcher.CONTAINER), self.calls)
        self.assertTrue(any('error' in action for action in self.receipt()['cleanup_actions']))

    def test_unknown_container_state_quarantines_and_blocks_next_run(self):
        self.fail_stop = self.fail_inspect = True
        self.assertIsNotNone(self.run_main())
        self.assertTrue(self.stopped.is_set())
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
        self.assertEqual(self.policies, ['STABLE_PEAK'])
        self.assertTrue(self.receipt()['recovery_required'])
        self.launcher.OUT = self.root/'retry'
        self.launcher.OUT.mkdir()
        self.assertIsNotNone(self.run_main())
        self.assertEqual(self.calls.count('launch'), 1)
        self.assertEqual(self.policies, ['STABLE_PEAK'])

    def test_successful_run_recovers_without_killing_container(self):
        self.process.running, self.process.returncode = False, 0
        self.assertIsNone(self.run_main())
        self.assertTrue(self.receipt()['benchmark_complete'])
        self.assertTrue(self.receipt()['recovery_verified'])
        self.assertFalse(self.receipt()['quarantined'])
        self.assertFalse(self.launcher.RECOVERY_MARKER.exists())
        self.assertFalse(any(isinstance(call, tuple) and call[0] in ('stop', 'kill') for call in self.calls))

    def test_absence_after_forced_client_exit_stays_quarantined(self):
        self.fail_stop = self.stop_timeout_but_exited = self.inspect_missing = True
        self.assertIsNotNone(self.run_main())
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
        self.assertEqual(self.policies, ['STABLE_PEAK'])
        self.assertFalse(self.receipt()['recovery_verified'])

    def test_removed_container_after_clean_attached_exit_can_recover(self):
        self.process.running, self.process.returncode = False, 0
        self.inspect_missing = True
        self.assertIsNone(self.run_main())
        self.assertTrue(self.receipt()['recovery_verified'])
        self.assertNotIn(('kill', self.launcher.CONTAINER), self.calls)

    def test_inspect_permission_error_is_not_container_absence(self):
        self.inspect_permission_denied = True
        self.assertIsNotNone(self.run_main())
        self.assertEqual(self.policies, ['STABLE_PEAK'])
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())

    def test_unreaped_client_blocks_policy_recovery(self):
        self.fail_stop = self.client_stuck = True
        self.assertIsNotNone(self.run_main())
        self.assertTrue(self.stopped.is_set())
        self.assertEqual(self.calls.count('client-terminate'), 2)
        self.assertNotIn(('container', 'inspect'), self.calls)
        self.assertEqual(self.policies, ['STABLE_PEAK'])
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())

    def test_gpu_work_must_drain_before_auto(self):
        self.busy = True
        self.assertIsNotNone(self.run_main())
        self.assertEqual(self.policies, ['STABLE_PEAK'])
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
        self.assertFalse(self.receipt()['recovery_verified'])

    def test_failed_auto_recovery_retains_marker(self):
        self.fail_restore = True
        self.assertIsNotNone(self.run_main())
        self.assertEqual(self.policies, ['STABLE_PEAK', 'AUTO'])
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
        self.assertTrue(self.receipt()['quarantined'])

    def test_initial_setter_failure_still_recovers(self):
        self.fail_initial_policy = True
        self.assertIsNotNone(self.run_main())
        self.assertNotIn('launch', self.calls)
        self.assertEqual(self.policies, ['STABLE_PEAK', 'AUTO'])
        self.assertFalse(self.launcher.RECOVERY_MARKER.exists())

    def test_receipt_failure_preserves_unresolved_marker(self):
        self.fail_inspect = self.fail_receipt = True
        self.assertIsInstance(self.run_main(), OSError)
        self.assertTrue(self.stopped.is_set())
        self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
        self.assertEqual(self.policies, ['STABLE_PEAK'])

    def test_preexisting_marker_blocks_before_policy_or_launch(self):
        self.launcher.RECOVERY_MARKER.write_text('{"container":"previous-attempt"}\n')
        self.assertIsNotNone(self.run_main())
        self.assertEqual(self.policies, [])
        self.assertNotIn('launch', self.calls)
        self.assertTrue(self.receipt()['quarantined'])

    def check_blocked_telemetry(self, block_after_auto):
        release = threading.Event()
        telemetry = self.launcher.telemetry

        def blocked():
            if 'launch' in self.calls and (self.policy == 'auto') == block_after_auto:
                release.wait(1)
            return telemetry()

        self.launcher.telemetry = blocked
        self.launcher.RECOVERY_TELEMETRY_TIMEOUT = .01
        try:
            self.assertIsInstance(self.run_main(), TimeoutError)
            self.assertTrue(self.launcher.RECOVERY_MARKER.exists())
            self.assertFalse(self.receipt()['recovery_verified'])
            self.assertEqual(self.policies, ['STABLE_PEAK', 'AUTO'] if block_after_auto else ['STABLE_PEAK'])
        finally:
            release.set()

    def test_blocking_drain_telemetry_is_bounded_and_quarantined(self):
        self.check_blocked_telemetry(False)

    def test_blocking_final_telemetry_is_bounded_and_quarantined(self):
        self.check_blocked_telemetry(True)


if __name__ == '__main__':
    unittest.main()
