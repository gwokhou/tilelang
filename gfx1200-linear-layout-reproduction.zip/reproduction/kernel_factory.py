import tilelang.language as T
from tilelang.layout import make_linear_layout

def factory(M, N, K, linear):
        @T.prim_func
        def main(A: T.Tensor((M, K), 'bfloat16'), B: T.Tensor((K, N), 'bfloat16'),
                 C: T.Tensor((M, N), 'bfloat16')):
            with T.Kernel(T.ceildiv(N, 128), T.ceildiv(M, 128), threads=128) as (bx, by):
                A_shared = T.alloc_shared((128, 32), 'bfloat16')
                B_shared = T.alloc_shared((32, 128), 'bfloat16')
                C_local = T.alloc_fragment((128, 128), 'float32')
                if linear:
                    T.annotate_layout({A_shared: make_linear_layout(A_shared),
                                       B_shared: make_linear_layout(B_shared)})
                T.clear(C_local)
                for k in T.Pipelined(T.ceildiv(K, 32), num_stages=0):
                    T.copy(A[by * 128, k * 32], A_shared)
                    T.copy(B[k * 32, bx * 128], B_shared)
                    T.gemm(A_shared, B_shared, C_local)
                T.copy(C_local, C[by * 128, bx * 128])
        return main
