"""Configurable reproduction launcher; adapted from the measured policy/recovery supervisor."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time
import traceback

PARSER = argparse.ArgumentParser(description="Run the fixed benchmark or AMD profiling from explicit local builds.")
PARSER.add_argument('--config', type=Path, required=True)
PARSER.add_argument('--out', type=Path, required=True)
PARSER.add_argument('--mode', choices=['bench', 'counters', 'att'], required=True)
PARSER.add_argument('--policy', choices=['AUTO', 'STABLE_PEAK'], default='STABLE_PEAK')
PARSER.add_argument('--dry-run', action='store_true', help='Print the Docker command without starting processes, touching clocks, or creating outputs.')
ARGS = PARSER.parse_args()
CONFIG = json.loads(ARGS.config.read_text())
PHASE = ARGS.mode
POLICY = ARGS.policy
EXPECTED_POLICY = 'profile_peak' if POLICY == 'STABLE_PEAK' else 'auto'
SCRIPTS = Path(__file__).resolve().parent
OUT = ARGS.out.resolve() / ('bench-' + POLICY.lower().replace('_', '-') if PHASE == 'bench' else PHASE)
DEVICE = Path('/sys/bus/pci/devices') / CONFIG['bdf']
UUID = CONFIG['smi_uuid']
IMAGE = CONFIG['image']
CONTAINER = 'tilelang-layout-reproduction-' + str(os.getpid())
SMI = CONFIG['amd_smi']
LOCK_DIR = Path('/run/lock')
RECOVERY_MARKER = LOCK_DIR / f'gpu-{UUID}.recovery-required.json'
RECOVERY_TELEMETRY_TIMEOUT = 2
if PHASE != 'bench' and POLICY != 'STABLE_PEAK':
    PARSER.error('Profiling reproduction uses STABLE_PEAK; use AUTO only for --mode bench.')


def container_command():
    command = ['docker', 'run', '--rm', '--pull=never', '--name', CONTAINER,
               '--network=none', '--user', f'{os.getuid()}:{os.getgid()}',
               '--cap-drop=ALL', '--security-opt', 'no-new-privileges=true',
               '--device=/dev/kfd', '--device=' + CONFIG['render_node'], '--shm-size=2g',
               '-e', 'ROCR_VISIBLE_DEVICES=GPU-' + CONFIG['hip_uuid'],
               '-e', 'BENCH_HIP_UUID=' + CONFIG['hip_uuid'], '-e', 'BENCH_BDF=' + CONFIG['bdf'],
               '-e', 'TILELANG_DISABLE_CACHE=1', '-e', 'TILELANG_CLEANUP_TEMP_FILES=1',
               '-e', 'PYTHONUNBUFFERED=1', '-e', 'TMPDIR=/evidence/temp',
               '-e', 'OMP_NUM_THREADS=4', '-e', 'OPENBLAS_NUM_THREADS=4',
               '-v', f'{OUT}:/evidence', '-v', f'{SCRIPTS}:/scripts:ro',
               '-v', CONFIG['venv'] + ':/workspace/.venv:ro']
    for variant in ('baseline', 'candidate'):
        command += ['-v', CONFIG[variant + '_source'] + f':/{variant}:ro',
                    '-v', CONFIG[variant + '_build'] + f':/{variant}/build:ro',
                    '-v', CONFIG['thirdparty'] + f':/{variant}/3rdparty:ro',
                    '-v', CONFIG['venv'] + f':/{variant}/.venv:ro']
    command += ['-w', '/evidence', '--entrypoint', 'python3', IMAGE]
    if PHASE == 'bench':
        command += ['/scripts/bench.py', '--shapes', '0,1,2,3,4,5,6,7', '--rounds', '6', '--suffix', 'main']
    else:
        command += ['/scripts/jobs.py', '--phase', 'capture', '--plan', PHASE + '-plan.json']
    return command


def prepare():
    import hashlib
    import re
    if not re.fullmatch(r'[0-9a-fA-F]{16}', CONFIG['hip_uuid']):
        raise ValueError('hip_uuid must be the 16-hex-digit HIP unique ID, without GPU-.')
    if not re.fullmatch(r'[0-9a-fA-F-]{36}', UUID):
        raise ValueError('smi_uuid must be the AMD-SMI UUID.')
    if not re.fullmatch(r'[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-7]', CONFIG['bdf']):
        raise ValueError('bdf must be a full PCI address.')
    for key in ('baseline_source', 'baseline_build', 'candidate_source', 'candidate_build', 'thirdparty', 'venv'):
        path = Path(CONFIG[key])
        if not path.is_absolute() or not path.is_dir():
            raise ValueError(f'{key} must name an existing absolute directory: {path}')
    for key in ('baseline_source', 'candidate_source'):
        if not (Path(CONFIG[key])/'tilelang/__init__.py').is_file():
            raise ValueError(f'{key} must be a TileLang source checkout.')
    if not (Path(CONFIG['venv'])/'lib/python3.14/site-packages/tvm_ffi').exists():
        raise ValueError('venv must provide Python 3.14 apache-tvm-ffi and TileLang Python dependencies.')
    native = {}
    for variant in ('baseline', 'candidate'):
        for lib in ('libtilelang.so', 'libtvm_compiler.so'):
            path = Path(CONFIG[variant + '_build'])/'lib'/lib
            with path.open('rb') as source:
                native[f'{variant}/{lib}'] = hashlib.file_digest(source, 'sha256').hexdigest()
    OUT.mkdir(parents=True, exist_ok=False)
    save('configuration.json', CONFIG)
    save('native-manifest.json', native)
    save('scripts-manifest.json', {f.name:hashlib.sha256(f.read_bytes()).hexdigest()
                                   for f in sorted(SCRIPTS.glob('*.py'))})


def save(name, data):
    path = OUT/name
    temporary = path.with_name(path.name+'.new')
    temporary.write_text(json.dumps(data,indent=2)+'\n')
    temporary.replace(path)

def read(path):
    try: return path.read_text().strip()
    except OSError: return None

def telemetry():
    row = {'time':time.time(),'runtime_status':read(DEVICE/'power/runtime_status'),
           'performance_level':read(DEVICE/'power_dpm_force_performance_level'),
           'busy_percent':read(DEVICE/'gpu_busy_percent'),
           'kfd_pids':sorted(p.name for p in Path('/sys/class/kfd/kfd/proc').iterdir()),
           'sclk':read(DEVICE/'pp_dpm_sclk'),'mclk':read(DEVICE/'pp_dpm_mclk')}
    for hwmon in (DEVICE/'hwmon').glob('hwmon*'):
        for pattern in ('temp*_input','temp*_label','power*_average','power*_cap','freq*_input'):
            for path in hwmon.glob(pattern): row[path.name] = read(path)
    return row

def metric(label):
    result = subprocess.run([SMI,'metric','--gpu',UUID,'--perf-level','--clock','--temperature','--power','--json'],
                            capture_output=True,text=True,check=True,timeout=15)
    record = json.loads(result.stdout)
    save(f'amd-smi-{label}.json',record)
    assert len(record['gpu_data']) == 1
    return record['gpu_data'][0]

def set_policy(level):
    command = ['sudo','-n',SMI,'set','-l',level,'-g',UUID]
    result = subprocess.run(command,capture_output=True,text=True,timeout=20)
    with (OUT/'policy-commands.jsonl').open('a') as f:
        f.write(json.dumps({'time':time.time(),'command':command,'returncode':result.returncode,
                            'stdout':result.stdout,'stderr':result.stderr})+'\n')
    assert result.returncode == 0, (result.returncode,result.stdout,result.stderr)
    assert not any(marker in (result.stdout+result.stderr).lower() for marker in
                   ('unable to set','failed to set','error:'))

def interrupted(signum, frame):
    raise RuntimeError(f'supervisor interrupted by signal {signum}')


def mark_recovery_required():
    # Persist the obligation before the first setter or container launch. A
    # process exit releases flock locks, so locks alone cannot quarantine a GPU.
    fd = os.open(RECOVERY_MARKER, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as output:
        json.dump({'container': CONTAINER, 'smi_uuid': UUID, 'bdf': CONFIG['bdf'],
                   'hip_uuid': CONFIG['hip_uuid'], 'evidence': str(OUT),
                   'started_unix': time.time()}, output)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())


def stop_container(proc, receipt):
    """Reap the Docker client, then independently verify container exit."""
    if proc is None:
        return
    actions = receipt.setdefault('cleanup_actions', [])

    def command(argv, timeout):
        try:
            result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
            actions.append({'command': argv, 'returncode': result.returncode,
                            'stdout': result.stdout, 'stderr': result.stderr})
            return result
        except Exception as error:
            actions.append({'command': argv, 'error': repr(error)})
            return None

    def wait_client():
        try:
            proc.wait(timeout=5)
        except Exception as error:
            actions.append({'action': 'wait-client', 'error': repr(error)})

    if proc.poll() is None:
        command(['docker', 'stop', '--time', '20', CONTAINER], 30)
    wait_client()
    # A live client could still submit a delayed container start. Reap it before
    # accepting an absent container as evidence of completion.
    forced_client_exit = False
    for terminate in (proc.terminate, proc.kill):
        if proc.poll() is not None:
            break
        forced_client_exit = True
        try:
            terminate()
        except Exception as error:
            actions.append({'action': 'terminate-client', 'error': repr(error)})
        wait_client()
    if proc.poll() is None:
        raise RuntimeError('Docker client did not exit; recovery remains required')
    allow_absence = not forced_client_exit and proc.returncode == 0

    def exited():
        result = command(['docker', 'container', 'inspect', '--format', '{{json .State}}', CONTAINER], 10)
        if result is None:
            return False
        if result.returncode != 0:
            # A killed client may leave a delayed daemon create/start request.
            # Only a clean attached-run exit makes --rm absence conclusive.
            return allow_absence and any(f'No such {kind}: {CONTAINER}' in result.stderr
                                         for kind in ('container', 'object'))
        state = json.loads(result.stdout)
        return (state.get('Running') is False and state.get('Restarting') is False
                and state.get('Status') in ('exited', 'dead'))

    if not exited():
        command(['docker', 'kill', CONTAINER], 20)
        if not exited():
            raise RuntimeError('Container exit is unverified; recovery remains required')


def recovery_telemetry():
    # A blocking sysfs read must not defeat cleanup deadlines. This worker only
    # reads telemetry; a timed-out daemon worker cannot submit work or set policy.
    result = queue.Queue(maxsize=1)

    def probe():
        try:
            result.put((telemetry(), None))
        except Exception as error:
            result.put((None, error))

    threading.Thread(target=probe, name='gpu-recovery-probe', daemon=True).start()
    try:
        row, error = result.get(timeout=RECOVERY_TELEMETRY_TIMEOUT)
    except queue.Empty as error:
        raise TimeoutError('Recovery telemetry timed out; recovery remains required') from error
    if error is not None:
        raise error
    return row


def wait_for_drain():
    deadline = time.monotonic() + 10
    while True:
        drained = recovery_telemetry()
        if not drained['kfd_pids']:
            return drained
        if time.monotonic() >= deadline:
            raise RuntimeError('GPU work has not drained; recovery remains required')
        time.sleep(.25)


def main():
    assert not (OUT/'run-main.exit').exists(), 'Use a fresh evidence directory for a new attempt'
    locks = []
    stop = threading.Event()
    thread = None
    proc = None
    changed = False
    recovered = False
    policy_violation = []
    receipt = {'started_unix':time.time(),'policy':POLICY,'recovery_required':False}
    previous_handlers = {sig: signal.signal(sig, interrupted)
                         for sig in (signal.SIGTERM, signal.SIGINT)}
    try:
        for layer in ('L1-ownership','L2-execution'):
            fd = os.open(LOCK_DIR / f'gpu-{UUID}.{layer}.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
            try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BaseException:
                os.close(fd)
                raise
            locks.append(fd)
        if os.path.lexists(RECOVERY_MARKER):
            raise RuntimeError(f'Unresolved recovery marker: {RECOVERY_MARKER}. '
                               'Complete the manual recovery procedure in README.md before retrying.')
        before = telemetry()
        assert not before['kfd_pids'], before
        save('host-before-main.json',before)
        original = metric('before')
        assert original['perf_level'] == 'AMDSMI_DEV_PERF_LEVEL_AUTO', original['perf_level']
        receipt.update(original_policy='AUTO',recovery_required=True)
        save('lifecycle.json',receipt)
        mark_recovery_required()
        changed = True  # Recovery obligation starts before the first setter.
        set_policy(POLICY)
        established = metric('established')
        assert established['perf_level'] == 'AMDSMI_DEV_PERF_LEVEL_' + POLICY, established
        peak = telemetry()
        assert peak['performance_level'] == EXPECTED_POLICY, peak
        save('host-peak-established.json',peak)
        print('Requested GPU policy established and verified; launching experiment.',flush=True)
        def monitor():
            try:
                with (OUT/'telemetry-main.jsonl').open('w') as f:
                    while not stop.is_set():
                        row = telemetry()
                        f.write(json.dumps(row)+'\n'); f.flush()
                        if row['performance_level'] != EXPECTED_POLICY and not (POLICY == 'AUTO' and row['performance_level'] is None and row['runtime_status'] == 'suspended'):
                            policy_violation.append(row)
                        stop.wait(.25)
            except Exception:
                policy_violation.append({'monitor_error': traceback.format_exc()})
        # A blocked telemetry read must not keep the interpreter alive forever.
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        command = container_command()
        save('command-main.json',command)
        (OUT/'temp').mkdir(exist_ok=True)
        with (OUT/'run-main.log').open('w') as log:
            proc = subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
            deadline = time.monotonic()+1800
            while proc.poll() is None:
                if policy_violation: raise RuntimeError(f'Policy changed while running: {policy_violation[0]}')
                if time.monotonic() > deadline: raise TimeoutError('30-minute workload timeout')
                stop.wait(.5)
        (OUT/'run-main.exit').write_text(str(proc.returncode)+'\n')
        assert proc.returncode == 0, f'Benchmark failed, rc={proc.returncode}; see run-main.log'
        receipt['benchmark_complete'] = True
        print('Benchmark finished; verifying cleanup and restoring AUTO.',flush=True)
    except BaseException:
        receipt['error'] = traceback.format_exc()
        raise
    finally:
        signal.signal(signal.SIGTERM,signal.SIG_IGN)
        signal.signal(signal.SIGINT,signal.SIG_IGN)
        # This phase is independent of every Docker and policy recovery call.
        stop.set()
        try:
            if thread is not None:
                try:
                    thread.join(timeout=5)
                except Exception:
                    receipt['monitor_cleanup_error'] = traceback.format_exc()
                receipt['monitor_stopped'] = not thread.is_alive()
            if changed:
                stop_container(proc, receipt)
                drained = wait_for_drain()
                save('host-drained.json',drained)
                set_policy('AUTO')
                restored = metric('restored')
                assert restored['perf_level'] == 'AMDSMI_DEV_PERF_LEVEL_AUTO', restored
                after = recovery_telemetry()
                save('host-after-main.json',after)
                assert not after['kfd_pids']
                assert after['performance_level'] in (None,'auto')
                recovered = True
                RECOVERY_MARKER.unlink()
                print('AUTO restored and verified; no remaining KFD processes.',flush=True)
        except BaseException:
            receipt['recovery_error'] = traceback.format_exc()
            raise
        finally:
            quarantined = os.path.lexists(RECOVERY_MARKER)
            receipt.update(recovery_required=(changed and not recovered) or quarantined,
                           recovery_verified=recovered, quarantined=quarantined,
                           recovery_marker=str(RECOVERY_MARKER), ended_unix=time.time(),
                           policy_violations=policy_violation)
            try:
                if quarantined:
                    print(f'Recovery remains unresolved; this launcher will refuse new runs. '
                          f'Keep {RECOVERY_MARKER} until manual recovery is verified.', file=sys.stderr)
                save('lifecycle.json',receipt)
            finally:
                try:
                    for fd in reversed(locks):
                        try: fcntl.flock(fd,fcntl.LOCK_UN)
                        finally: os.close(fd)
                finally:
                    for sig, handler in previous_handlers.items():
                        signal.signal(sig, handler)

if __name__ == '__main__':
    if ARGS.dry_run:
        print(json.dumps(container_command(), indent=2))
    else:
        prepare()
        main()
