import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import statistics as stats

import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--policy', choices=['AUTO', 'STABLE_PEAK'], default='STABLE_PEAK')
args = parser.parse_args()
OUT = args.out.resolve()
EXPECTED_POLICY = 'profile_peak' if args.policy == 'STABLE_PEAK' else 'auto'
SHAPES = [(4096, 1024, 8192), (4096, 8192, 8192), (4096, 28672, 8192), (4096, 8192, 28672),
          (8192, 1024, 8192), (8192, 8192, 8192), (8192, 28672, 8192), (8192, 8192, 28672)]
LABELS = ('baseline_default', 'candidate_default', 'candidate_linear')
records = [json.loads(line) for line in (OUT / 'results-main.jsonl').read_text().splitlines()]
assert len([r for r in records if r['type'] == 'complete']) == 1
assert records[-1]['type'] == 'complete' and records[-1]['rounds'] == 6
measurements = [r for r in records if r['type'] == 'measurement']
correctness = [r for r in records if r['type'] == 'correctness']
assert len(measurements) == 8 * 3 * 6
assert len(correctness) == 8 * 2
assert all(c['passed'] and c['guard_passed'] for r in correctness for c in r['checks'].values())
assert all(r['guard_passed'] and len(r['samples_ms']) == r['n_repeat'] for r in measurements)
assert all(t > 0 and math.isfinite(t) for r in measurements for t in r['samples_ms'])
assert all(r['median_ms'] == stats.median(r['samples_ms']) for r in measurements)

def percentile(values, q):
    values = sorted(values)
    x = q * (len(values) - 1)
    lo = int(x)
    hi = min(lo + 1, len(values) - 1)
    return values[lo] * (hi - x) + values[hi] * (x - lo) if lo != hi else values[lo]

def ratio_ci(a, b, rng):
    ratios = []
    for _ in range(10000):
        idx = [rng.randrange(6) for _ in range(6)]
        ratios.append(stats.median([a[i] for i in idx]) / stats.median([b[i] for i in idx]))
    return [percentile(ratios, .025), percentile(ratios, .975)]

lifecycle = json.loads((OUT / 'lifecycle.json').read_text())
assert lifecycle['benchmark_complete'] and lifecycle['recovery_verified'] and not lifecycle['recovery_required']
assert not lifecycle['policy_violations']
rows = []
code_matches = {}
for sid, shape in enumerate(SHAPES):
    items = [r for r in measurements if r['sid'] == sid]
    assert len({(r['label'], r['round']) for r in items}) == 18
    assert len({r['n_repeat'] for r in items}) == 1
    orders = []
    for round_id in range(6):
        block = sorted((r for r in items if r['round'] == round_id), key=lambda r: r['position'])
        orders.append(tuple(r['label'] for r in block))
    assert set(orders) == set(itertools.permutations(LABELS))
    checks = [r for r in correctness if r['loaded'] == sid]
    assert checks[0]['input_hashes'] == checks[1]['input_hashes']
    times = {label: [next(r['median_ms'] for r in items if r['label'] == label and r['round'] == n)
                     for n in range(6)] for label in LABELS}
    medians = {label: stats.median(values) for label, values in times.items()}
    base, default, linear = [medians[x] for x in LABELS]
    rng = random.Random(20261101 + sid)
    row = {'id': f'M{sid}', 'M': shape[0], 'N': shape[1], 'K': shape[2],
           'baseline_ms': base, 'candidate_default_ms': default, 'candidate_linear_ms': linear,
           'default_vs_baseline_latency_pct': 100 * (default / base - 1),
           'linear_vs_default_latency_pct': 100 * (linear / default - 1),
           'linear_vs_baseline_latency_pct': 100 * (linear / base - 1),
           'linear_vs_default_speedup': default / linear,
           'default_vs_baseline_speedup': base / default,
           'linear_vs_baseline_speedup': base / linear,
           'linear_vs_default_speedup_ci95': ratio_ci(times[LABELS[1]], times[LABELS[2]], rng),
           'default_vs_baseline_speedup_ci95': ratio_ci(times[LABELS[0]], times[LABELS[1]], rng),
           'samples_per_block': items[0]['n_repeat'],
           'round_medians_ms': times,
           'block_median_range_ms': {label: [min(t), max(t)] for label, t in times.items()},
           'tflops': {label: 2 * math.prod(shape) / value * 1e-9 for label, value in medians.items()}}
    rows.append(row)
    paths = [OUT / 'kernel-sources' / label / f'M{sid}.hip' for label in LABELS]
    sources = [path.read_bytes() for path in paths]
    code_matches[f'M{sid}'] = {'default_equal': sources[0] == sources[1],
                              'sha256': {label: hashlib.sha256(source).hexdigest()
                                         for label, source in zip(LABELS, sources)}}
assert all(x['default_equal'] for x in code_matches.values())

telemetry = [json.loads(line) for line in (OUT / 'telemetry-main.jsonl').read_text().splitlines()]
windows = [(r['start_unix'], r['end_unix']) for r in measurements]
active = [t for t in telemetry if any(start <= t['time'] <= end for start, end in windows)]
assert active and all(t['performance_level'] == EXPECTED_POLICY for t in active)
def metric(key, scale=1):
    values = [float(t[key]) / scale for t in active if t.get(key) is not None]
    return {'min': min(values), 'median': stats.median(values), 'max': max(values), 'n': len(values)} if values else None
levels = sorted({t['performance_level'] for t in telemetry if t['performance_level'] is not None})
assert levels == [EXPECTED_POLICY]
after = json.loads((OUT / 'host-after-main.json').read_text())
assert not after['kfd_pids'] and after['performance_level'] in (None, 'auto')
summary = {'rows': rows, 'total_timed_samples': sum(len(r['samples_ms']) for r in measurements),
           'blocks': len(measurements), 'correctness_cases': sum(len(r['checks']) for r in correctness),
           'geomean_default_vs_baseline_speedup': stats.geometric_mean(r['default_vs_baseline_speedup'] for r in rows),
           'geomean_linear_vs_default_speedup': stats.geometric_mean(r['linear_vs_default_speedup'] for r in rows),
           'geomean_linear_vs_baseline_speedup': stats.geometric_mean(r['linear_vs_baseline_speedup'] for r in rows),
           'default_device_code': code_matches,
           'telemetry': {'observed_policy': levels, 'timing_window_snapshots': len(active),
                         'edge_c': metric('temp1_input', 1000), 'junction_c': metric('temp2_input', 1000),
                         'memory_c': metric('temp3_input', 1000), 'power_w': metric('power1_average', 1e6),
                         'sclk_mhz': metric('freq1_input', 1e6), 'mclk_mhz': metric('freq2_input', 1e6),
                         'cleanup_kfd_pids': after['kfd_pids']}}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
columns = [k for k, v in rows[0].items() if not isinstance(v, (dict, list))]
with (OUT / 'summary.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=columns)
    writer.writeheader()
    writer.writerows({k: row[k] for k in columns} for row in rows)
table = ['| Shape | M × N × K | Base default (ms) | PR default (ms) | PR linear (ms) | Default Δ vs base | Linear Δ vs PR default |',
         '|---|---|---:|---:|---:|---:|---:|']
for r in rows:
    table.append(f'| {r["id"]} | {r["M"]} × {r["N"]} × {r["K"]} | {r["baseline_ms"]:.4f} | '
                 f'{r["candidate_default_ms"]:.4f} | {r["candidate_linear_ms"]:.4f} | '
                 f'{r["default_vs_baseline_latency_pct"]:+.2f}% | {r["linear_vs_default_latency_pct"]:+.2f}% |')
(OUT / 'table.md').write_text('\n'.join(table) + '\n')
print('\n'.join(table))
print(json.dumps({k: v for k, v in summary.items() if k not in ('rows', 'default_device_code')}, indent=2))
