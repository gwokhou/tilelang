"""Fixed-shape, fixed-configuration GEMM experiment; no autotuning.

Each worker owns one independently built TileLang snapshot. The parent serializes
all GPU submissions and balances the six possible treatment orders per shape.
"""
import argparse
import ctypes
import gc
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback

SHAPES = [(4096, 1024, 8192), (4096, 8192, 8192),
          (4096, 28672, 8192), (4096, 8192, 28672),
          (8192, 1024, 8192), (8192, 8192, 8192),
          (8192, 28672, 8192), (8192, 8192, 28672)]
OUT = Path('/evidence')
PREFIX = 'BENCH_RESULT='
LABELS = ('baseline_default', 'candidate_default', 'candidate_linear')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def emit(value):
    print(PREFIX + json.dumps(value), flush=True)

def worker(variant):
    import numpy as np
    import torch
    assert torch.version.hip and torch.cuda.device_count() == 1
    torch.cuda.set_device(0)
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    prop = torch.cuda.get_device_properties(0)
    assert prop.gcnArchName.split(':')[0] == 'gfx1200', prop
    hip = ctypes.CDLL('/usr/local/lib/python3.14/dist-packages/_rocm_sdk_core/lib/libamdhip64.so.7')
    bus = ctypes.create_string_buffer(32)
    assert hip.hipDeviceGetPCIBusId(bus, len(bus), 0) == 0
    assert bus.value.decode().lower() == os.environ['BENCH_BDF'].lower()
    normalized_uuid = bytes.fromhex(str(prop.uuid).replace('-', '')).decode('ascii')
    assert normalized_uuid == os.environ['BENCH_HIP_UUID'], normalized_uuid
    import tilelang
    import tilelang.language as T
    from tilelang.layout import make_linear_layout
    root = Path(tilelang.__file__).resolve().parents[1]
    assert root == Path('/' + variant), root
    environment = {'variant': variant, 'torch': torch.__version__, 'hip': torch.version.hip,
                   'python': sys.version, 'numpy': np.__version__, 'tilelang': tilelang.__version__,
                   'tilelang_path': str(root), 'device_name': prop.name,
                   'arch': prop.gcnArchName, 'pci_bus_id': bus.value.decode(),
                   'uuid': normalized_uuid, 'total_memory': prop.total_memory,
                   'native_sha256': sha(root / 'build/lib/libtilelang.so'),
                   'tvm_sha256': sha(root / 'build/lib/libtvm_compiler.so')}
    (OUT / f'environment-{variant}.json').write_text(json.dumps(environment, indent=2) + '\n')

    def factory(M, N, K, linear):
        @T.prim_func
        def main(A: T.Tensor((M, K), 'bfloat16'), B: T.Tensor((K, N), 'bfloat16'),
                 C: T.Tensor((M, N), 'bfloat16')):
            with T.Kernel(T.ceildiv(N, 128), T.ceildiv(M, 128), threads=128) as (bx, by):
                A_shared = T.alloc_shared((128, 32), 'bfloat16')
                B_shared = T.alloc_shared((32, 128), 'bfloat16')
                C_local = T.alloc_fragment((128, 128), 'float32')
                if linear:
                    T.annotate_layout({A_shared: make_linear_layout(A_shared),
                                       B_shared: make_linear_layout(B_shared)})
                T.clear(C_local)
                for k in T.Pipelined(T.ceildiv(K, 32), num_stages=0):
                    T.copy(A[by * 128, k * 32], A_shared)
                    T.copy(B[k * 32, bx * 128], B_shared)
                    T.gemm(A_shared, B_shared, C_local)
                T.copy(C_local, C[by * 128, bx * 128])
        return main

    kernels = {}
    data = None
    cache = torch.empty(256 * 1024 * 1024 // 4, device='cuda', dtype=torch.int32)
    cache.zero_()
    torch.cuda.synchronize()
    emit({'ready': environment})
    for line in sys.stdin:
        try:
            command = json.loads(line)
            op = command['op']
            if op == 'stop':
                torch.cuda.synchronize()
                emit({'stopped': True})
                return
            if op == 'compile':
                ids = command['ids']
                for sid in ids:
                    for linear in ([False] if variant == 'baseline' else [False, True]):
                        label = variant + ('_linear' if linear else '_default')
                        kernel = tilelang.compile(factory(*SHAPES[sid], linear),
                                                  target={'kind': 'hip', 'mcpu': 'gfx1200'},
                                                  execution_backend='tvm_ffi')
                        kernels[sid, linear] = kernel
                        dest = OUT / 'kernel-sources' / label
                        dest.mkdir(parents=True, exist_ok=True)
                        (dest / f'M{sid}.hip').write_text(kernel.get_kernel_source())
                        print(f'Compiled {label} M{sid}', flush=True)
                emit({'compiled': len(kernels)})
            elif op == 'load':
                data = None
                gc.collect()
                torch.cuda.empty_cache()
                sid = command['sid']
                M, N, K = SHAPES[sid]
                rng = np.random.default_rng(20261101 + sid)
                a_cpu = rng.integers(-2, 3, size=(M, K), dtype=np.int8)
                b_cpu = rng.integers(-2, 3, size=(K, N), dtype=np.int8)
                input_hashes = {'a_int8_sha256': hashlib.sha256(a_cpu).hexdigest(),
                                'b_int8_sha256': hashlib.sha256(b_cpu).hexdigest()}
                a = torch.from_numpy(a_cpu).to(device='cuda', dtype=torch.bfloat16)
                b = torch.from_numpy(b_cpu).to(device='cuda', dtype=torch.bfloat16)
                del a_cpu, b_cpu
                guarded = torch.full((M * N + 32,), 123, device='cuda', dtype=torch.bfloat16)
                c = guarded[16:-16].view(M, N)
                # Integer products and the entire K reduction fit exactly in FP32.
                expected = (a.float() @ b.float()).to(torch.bfloat16)
                checks = {}
                pilots = {}
                for linear in ([False] if variant == 'baseline' else [False, True]):
                    label = variant + ('_linear' if linear else '_default')
                    fn = lambda: kernels[sid, linear](a, b, c)
                    fn()
                    torch.cuda.synchronize()
                    torch.testing.assert_close(c, expected, rtol=0, atol=0)
                    assert bool(torch.all(guarded[:16] == 123) & torch.all(guarded[-16:] == 123))
                    checks[label] = {'passed': True, 'rtol': 0, 'atol': 0, 'guard_passed': True}
                    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
                    for _ in range(3):
                        fn()
                    start.record()
                    for _ in range(3):
                        fn()
                    end.record()
                    end.synchronize()
                    pilots[label] = start.elapsed_time(end) / 3
                del expected
                data = (sid, a, b, c, guarded)
                emit({'loaded': sid, 'input_hashes': input_hashes, 'checks': checks, 'pilot_ms': pilots})
            elif op == 'measure':
                sid, a, b, c, guarded = data
                linear = command['label'].endswith('_linear')
                fn = lambda: kernels[sid, linear](a, b, c)
                n = command['n_repeat']
                for _ in range(command['n_warmup']):
                    fn()
                torch.cuda.synchronize()
                starts = [torch.cuda.Event(enable_timing=True) for _ in range(n)]
                ends = [torch.cuda.Event(enable_timing=True) for _ in range(n)]
                begin = time.time()
                for start, end in zip(starts, ends):
                    cache.zero_()
                    start.record()
                    fn()
                    end.record()
                torch.cuda.synchronize()
                times = [start.elapsed_time(end) for start, end in zip(starts, ends)]
                assert all(t > 0 and math.isfinite(t) for t in times), times
                assert bool(torch.all(guarded[:16] == 123) & torch.all(guarded[-16:] == 123))
                emit({**command, 'sid': sid, 'start_unix': begin, 'end_unix': time.time(),
                      'samples_ms': times, 'median_ms': statistics.median(times), 'guard_passed': True})
            elif op == 'release':
                data = None
                a = b = c = guarded = fn = None
                gc.collect()
                torch.cuda.synchronize()
                torch.cuda.empty_cache()
                emit({'released': True})
            else:
                raise ValueError(command)
        except Exception:
            traceback.print_exc()
            emit({'error': traceback.format_exc()})
            return

def master(ids, rounds, suffix):
    workers = {}
    result_path = OUT / f'results-{suffix}.jsonl'
    def log(record):
        with result_path.open('a') as f:
            f.write(json.dumps(record) + '\n')
    def read(variant):
        proc = workers[variant]
        for line in proc.stdout:
            if line.startswith(PREFIX):
                result = json.loads(line[len(PREFIX):])
                if 'error' in result:
                    raise RuntimeError(result['error'])
                return result
            print(f'[{variant}] {line.rstrip()}', flush=True)
        raise RuntimeError(f'{variant} worker exited {proc.poll()}')
    def send(variant, command):
        workers[variant].stdin.write(json.dumps(command) + '\n')
        workers[variant].stdin.flush()
        return read(variant)
    try:
        for variant in ('baseline', 'candidate'):
            env = dict(os.environ, PYTHONPATH=f'/{variant}:/workspace/.venv/lib/python3.14/site-packages',
                       TILELANG_CACHE_DIR=f'/evidence/cache-{variant}', PYTHONUNBUFFERED='1')
            workers[variant] = subprocess.Popen([sys.executable, __file__, '--worker', variant],
                env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, cwd=f'/{variant}')
            ready = read(variant)
            log({'type': 'environment', **ready})
            print(f'{variant} ready: {ready["ready"]["device_name"]}', flush=True)
            send(variant, {'op': 'compile', 'ids': ids})
        orders = list(itertools.permutations(LABELS))
        for sid in ids:
            loaded = {}
            for variant in ('baseline', 'candidate'):
                loaded[variant] = send(variant, {'op': 'load', 'sid': sid})
                log({'type': 'correctness', 'variant': variant, **loaded[variant]})
            assert loaded['baseline']['input_hashes'] == loaded['candidate']['input_hashes']
            pilot = {key: val for value in loaded.values() for key, val in value['pilot_ms'].items()}
            n_repeat = max(10, min(200, math.ceil(600 / max(pilot.values()))))
            n_warmup = max(3, min(100, math.ceil(200 / min(pilot.values()))))
            print(f'M{sid} {SHAPES[sid]} correctness passed; pilot {pilot}; repeats={n_repeat}', flush=True)
            for r in range(rounds):
                order = orders[(r + sid) % len(orders)]
                for position, label in enumerate(order):
                    command = {'op': 'measure', 'label': label, 'round': r, 'position': position,
                               'n_repeat': n_repeat, 'n_warmup': n_warmup}
                    variant = 'baseline' if label.startswith('baseline') else 'candidate'
                    result = send(variant, command)
                    log({'type': 'measurement', **result})
                    print(f'M{sid} round {r + 1}/{rounds} {label}: {result["median_ms"]:.6f} ms', flush=True)
            for variant in ('baseline', 'candidate'):
                send(variant, {'op': 'release'})
        log({'type': 'complete', 'shapes': ids, 'rounds': rounds, 'end_unix': time.time()})
    finally:
        for variant, proc in workers.items():
            if proc.poll() is None:
                try:
                    send(variant, {'op': 'stop'})
                except Exception:
                    proc.terminate()
                try:
                    proc.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker', choices=['baseline', 'candidate'])
    parser.add_argument('--shapes', default='0,1,2,3,4,5,6,7')
    parser.add_argument('--rounds', type=int, default=6)
    parser.add_argument('--suffix', default='main')
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
    else:
        master([int(x) for x in args.shapes.split(',')], args.rounds, args.suffix)
