# gfx1200 linear-layout experiments

This supplement contains the experiment results and the scripts needed to rerun
the benchmark and AMD profiling. It contains no original sample streams, process
logs, raw ATT traces, code-object dumps, decoded per-wave timelines, build trees,
or development history. A new run creates its own local outputs for analysis.

The PR adds functional support for explicit canonical linear shared layouts.
These measurements characterize an opt-in layout; they do not establish a general
GEMM speedup or a fusion benefit.

## Recorded results

- `results/stable-peak.csv`: all eight shapes, baseline default, PR default,
  PR linear, and latency changes under STABLE_PEAK.
- `results/auto.csv`: the same comparison under AUTO.
- `results/counter-summary.csv`: per-counter median/min/max over three dispatches.
- `results/att-summary.csv`: scoped wave-residency and instruction-count results.
- `results/att-instruction-summary.csv`: aggregated instruction costs, not timelines.
- `results/kernel-metadata.csv`: six distinct compiled-kernel resource records.
- `results/experiment.json`: source/patch identity, environment, and validation counts.
- `results/hardening.json`: subsequent regression checks and source identity.
- `results/cleanup.json`: launcher recovery fix and CPU-only regression results.

The base is `0176ba1465b12758f41802bf838ddd68d43c9ee9`. Apply `candidate.patch`
to that revision for the measured candidate. Its SHA256 is
`837a9bac3fdf2aa544d31f9cd710098ebd27c45c3dc063165e2a8ab06860c742`.
Apply `post-benchmark.patch` on top to obtain the current PR, including the
callback handle cleanup, stronger tests and shorter documentation. Its rebuilt
default/linear HIP sources match all 16 measured sources byte-for-byte. The
follow-up passed correctness checks; benchmark timings were not remeasured.
The M0–M7 shapes are from the
[official benchmark README at a fixed revision](https://github.com/tile-ai/tilelang-benchmark/blob/b658f7e9f326156d11a09dff1e9825fa6d9a8767/README.md).

Recorded environment: Radeon RX 9060 XT (gfx1200), Python 3.14.4,
PyTorch 2.14.0+rocm10.1.0, HIP 7.16.26385, NumPy 2.5.3,
apache-tvm-ffi 0.1.12, AMD clang 24.0.0git, ROCprofiler-SDK 1.4.1,
and ROCprof Trace Decoder 0.2.2. The Docker image is:

```text
rocm/pytorch:rocm10.1.0_ubuntu26.04_py3.14_pytorch_release_2.14.0
rocm/pytorch@sha256:68295d40dcdcb53d9b50828f30017faad8cf5ad9a8c7923c5a815b414b45e3e6
```

## Prepare source builds and configuration

The launcher uses two **already built ROCm development checkouts**. It does not
download dependencies or build TileLang implicitly during measurement.

1. Prepare baseline and candidate directories at the base revision above, and
   apply `candidate.patch` only to candidate. For the current PR, also apply
   `post-benchmark.patch` to candidate before building. Initialize the recursive Git
   submodules at that revision. Both variants use the same `3rdparty` tree.
2. Build both variants in the recorded Docker image using the repository's
   source-build instructions. Use a shared Python 3.14 dependency environment
   (`requirements-dev.txt`, including `apache-tvm-ffi==0.1.12`) for both builds.
   It must contain `lib/python3.14/site-packages/tvm_ffi`; this dependency directory
   is mounted read-only ahead of the image's site-packages. Leave the image's
   PyTorch installation in use. Native outputs must contain `lib/libtilelang.so`
   and `lib/libtvm_compiler.so` in each configured build directory.
3. The measured native configuration enabled ROCm, Ascend, Z3 and PyPI Z3, and
   disabled CUDA, Metal and LLVM. For a source development build the relevant
   CMake settings are:

   ```bash
   cmake -S /workspace -B /workspace/build \
     -DUSE_ROCM=ON -DUSE_CUDA=OFF -DUSE_METAL=OFF -DUSE_ASCEND=ON \
     -DUSE_LLVM=OFF -DUSE_Z3=ON -DUSE_PYPI_Z3=ON
   cmake --build /workspace/build -j 6
   ```

   Here `/workspace`, `/workspace/build`, `/workspace/3rdparty`, and
   `/workspace/.venv` are the container mounts of the selected source, its separate
   build directory, the common submodules, and the common dependency environment.
   Set `PYTHONPATH=/workspace:/workspace/.venv/lib/python3.14/site-packages`.
   Use the same configuration for baseline and candidate. Rebuilds can have
   different native hashes; each run records the actual identities.
4. Copy `config.example.json` to `config.json` and replace the source/build,
   dependency, and device fields. `hip_uuid` is the HIP unique ID without the
   `GPU-` prefix; `smi_uuid` is the AMD-SMI UUID. They are different identifiers.
   Determine them, the full PCI BDF, and the matching render node on the host.
   The workload checks gfx1200, HIP UUID and BDF before executing GEMM.

Host prerequisites: Python 3, Docker access to the preloaded image, AMD-SMI,
access to `/dev/kfd` and the chosen render node, and noninteractive permission for
`sudo -n <amd_smi> set -l STABLE_PEAK -g <smi_uuid>` and the matching AUTO reset.
The launcher uses the existing host lock convention
`/run/lock/gpu-<smi_uuid>.{L1-ownership,L2-execution}.lock`; these must be writable
by the invoking user. It refuses existing KFD processes and a non-AUTO starting
policy. Before changing policy it creates
`/run/lock/gpu-<smi_uuid>.recovery-required.json`, recording the container name,
device identity and evidence directory. Every subsequent run checks this marker
under both locks and refuses to proceed while it exists.

Cleanup stops the monitor independently of Docker errors, uses bounded Docker
operations and recovery telemetry reads, and verifies container exit and GPU
drain before restoring AUTO. The marker is removed only after recovery is
verified. A missing container counts as completion only after a clean exit of
the attached Docker client; after forced client termination, a delayed daemon
start remains possible and absence alone keeps the device quarantined.

If recovery cannot be verified, the launcher records the error, retains the
marker, releases its process locks and exits with failure. The marker survives
process exit and blocks this launcher; it is not hardware isolation, is not
guaranteed to survive reboot, and does not prevent tools that ignore it from
using the device. The Docker workload has no network and cannot change host
clocks.

### Manual recovery after a failed cleanup

Do not remove a recovery marker merely to retry a benchmark. Coordinate with
other GPU users and perform recovery while holding both named host locks:

1. Read the marker and the evidence directory's `lifecycle.json`. Check that the
   recorded SMI UUID, HIP UUID and BDF identify the intended device.
2. Establish that the recorded container and its Docker client have finished.
   If Docker state is unknown or a create/start request may still be pending,
   resolve that uncertainty before proceeding; a missing container alone is
   insufficient after forced client termination.
3. Verify that KFD work has drained. Do not change the GPU policy while work may
   still be running.
4. Restore AUTO for the recorded SMI UUID, then verify it with AMD-SMI and the
   matching device's sysfs policy. A suspended device may omit the sysfs value,
   but the AMD-SMI policy check must still succeed.
5. Only after those checks, remove the recovery marker and release the locks.
   Never delete or replace the lock files themselves. Preserve the failed run's
   evidence when starting a fresh attempt.

## Run the benchmark

Inspect the command first; this does not create outputs, invoke Docker, or touch
the GPU:

```bash
python3 run.py --config config.json --out /absolute/path/to/new-run \
  --mode bench --policy STABLE_PEAK --dry-run
```

Run both policies into separate subdirectories of a new output root:

```bash
python3 run.py --config config.json --out /absolute/path/to/new-run --mode bench --policy AUTO
python3 analyze_benchmark.py --out /absolute/path/to/new-run/bench-auto --policy AUTO
python3 run.py --config config.json --out /absolute/path/to/new-run --mode bench --policy STABLE_PEAK
python3 analyze_benchmark.py --out /absolute/path/to/new-run/bench-stable-peak --policy STABLE_PEAK
```

The kernel uses BF16 NN inputs, FP32 accumulation, BF16 output, 128×128×32 tiles,
128 threads, `num_stages=0`, and no tuning. Inputs use NumPy PCG64 seed
`20261101 + shape_id`, integers in [-2, 2] converted to BF16. Full outputs are
checked against FP32 matmul rounded to BF16 with zero tolerance, with 16-element
guards before and after the output. Each measured call is preceded by a 256 MiB
cache flush outside the HIP event interval. There are six balanced treatment
orders per shape; all three variants use the same adaptive repeat count for that
shape. The analysis checks completeness, inputs, guards and default-code parity,
and writes `summary.csv`, `summary.json` and `table.md`.

Functional regression tests are in the candidate's existing
`testing/python/kernel/test_tilelang_kernel_gemm.py`. In its ROCm development
environment run:

```bash
python -m pytest testing/python/kernel/test_tilelang_kernel_gemm.py \
  -k 'wmma_shared_layout or rejects_incompatible_shared_layout or shared_layout_unsupported_modes' -q
```

## Optional AMD mechanism reproduction

Use the same builds and device configuration. The plans select M0, M1 and M2:

```bash
python3 run.py --config config.json --out /absolute/path/to/new-profile --mode counters
python3 run.py --config config.json --out /absolute/path/to/new-profile --mode att
python3 analyze_profile.py --out /absolute/path/to/new-profile
```

`counters-plan.json` defines 30 jobs with three selected kernel dispatches each;
all counters are device-qualified. `att-plan.json` defines six jobs with one
selected dispatch each on SE0/WGP1/SIMD0. The workload performs correctness,
ten warmups and a cache flush before selected dispatches. The original compiler
bundle is captured without changing compiler options, and AMD LLVM disassembles
the actual gfx1200 ELF. Analysis validates code-object identity, instruction
stitching, input hashes and `.text` consistency across modes.

The profile workload creates new local traces; their generation is required for
recomputing instruction-level results, but the original traces are not part of
this supplement. ATT costs overlap between waves and are not additive wall time.
The SDK labels the SQC LDS counters as emulated C1 events. STABLE_PEAK is a
driver policy, not an invariant frequency. Profiled durations must not replace
the separate benchmark results.

## Script validation status

The included workload, kernel and measurement logic comes from the executed
experiments. The distribution changes path/device configuration and combines
the original profiling job plans. This packaging revision is checked with
Python compilation, command-generation checks, and CPU re-analysis of the
existing results. It has not been rerun end to end on the GPU after these
configuration changes, nor freshly installed on another host. See
`script-validation.json` for the checks actually completed.

The launcher cleanup has 14 CPU-only regression tests. They inject Docker
stop/wait/inspect failures, ambiguous container absence, undrained GPU work,
blocked telemetry reads, policy-recovery failure and receipt-write failure;
they also check normal completion and rejection of retries while quarantined.
Docker, GPU telemetry and policy operations are replaced with controlled fakes;
lock operations use temporary files. Run them without GPU access:

```bash
python3 test_run.py -v
```

These tests validate recovery control flow, not a new GPU benchmark run.
