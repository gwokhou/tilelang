"""Summarize saved AMD profiler outputs; no GPU work or recompilation."""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import re
import statistics as st
import struct

import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
ROOT = parser.parse_args().out.resolve()
OUT = ROOT / 'analysis'
OUT.mkdir(exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text_section(path):
    data = path.read_bytes()
    assert data[:6] == b'\x7fELF\x02\x01'
    header = struct.unpack_from('<HHIQQQIHHHHHH', data, 16)
    offset, stride, count, string_idx = header[5], header[10], header[11], header[12]
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, offset+i*stride) for i in range(count)]
    strings = sections[string_idx]
    names = data[strings[4]:strings[4]+strings[5]]
    for s in sections:
        name = names[s[0]:].split(b'\0', 1)[0]
        if name == b'.text':
            return data[s[4]:s[4]+s[5]]
    raise AssertionError('No .text section')


def write_csv(name, rows):
    if not rows:
        return
    with (OUT/name).open('w') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


counter_rows, counter_summary, kernels = [], [], []
identity = defaultdict(list)
expected_device = None
for phase in ['counters', 'att']:
    for receipt in sorted((ROOT/phase).glob('M*/workload.json')):
        d = receipt.parent
        r = json.loads(receipt.read_text())
        assert r['correctness_passed'] and r['guards_passed']
        device = (r['uuid'], r['bdf'])
        if expected_device is None:
            expected_device = device
        assert device == expected_device, (device, expected_device)
        code_sha = sha(text_section(d/'kernel.hsaco'))
        source_sha = sha((d/'kernel.hip').read_bytes())
        assert source_sha == r['kernel_source_sha256']
        metadata = dict(re.findall(r'^\s+\.(\w+):\s+(\d+)\s*$', (d/'metadata.txt').read_text(), re.M))
        kernels.append({'job':str(d.relative_to(ROOT)), 'sid':r['sid'], 'layout':r['layout'],
                        'source_sha256':source_sha, 'text_sha256':code_sha,
                        **{k:int(metadata[k]) for k in ['vgpr_count','sgpr_count','vgpr_spill_count',
                            'sgpr_spill_count','private_segment_fixed_size','group_segment_fixed_size']}})
        identity[r['sid'],r['layout']].append((source_sha,code_sha,r['input_hashes']))
        for f in d.glob('*counter_collection.csv'):
            values = defaultdict(list)
            rows = list(csv.DictReader(f.open()))
            assert len({x['Dispatch_Id'] for x in rows}) == 3
            for x in rows:
                row = {'job':str(d.relative_to(ROOT)), 'sid':r['sid'], 'layout':r['layout'],
                       'dispatch':x['Dispatch_Id'], 'counter':x['Counter_Name'], 'value':float(x['Counter_Value'])}
                counter_rows.append(row)
                values[row['counter']].append(row['value'])
            for k, v in values.items():
                assert len(v) == 3, (d,k,v)
                counter_summary.append({'sid':r['sid'],'layout':r['layout'],'counter':k,'median':st.median(v),
                                        'min':min(v),'max':max(v),'n':len(v),'job':str(d.relative_to(ROOT))})

for key, values in identity.items():
    assert all(x == values[0] for x in values), (key, values)

write_csv('counter-samples.csv', counter_rows)
write_csv('counter-summary.csv', counter_summary)
write_csv('kernel-metadata.csv', kernels)

att_groups, att_waves, att_summary, att_loops = [], [], [], []
for phase in ['att']:
    for f in sorted((ROOT/phase).glob('M*/stats_*.csv')):
        d = f.parent
        r = json.loads((d/'workload.json').read_text())
        rows = list(csv.DictReader(f.open()))
        groups = defaultdict(lambda: Counter())
        for row in rows:
            if not int(row['Hitcount']):
                continue
            op = row['Instruction'].split()[0]
            for k in ['Hitcount','Latency','Stall','Idle']:
                groups[op][k] += int(row[k])
        for op, counts in groups.items():
            att_groups.append({'sid':r['sid'], 'layout':r['layout'], 'opcode':op, **counts,
                               **{f'{k}_per_hit':counts[k]/counts['Hitcount'] for k in ['Latency','Stall','Idle']}})
        u = next(d.glob('ui_output*'))
        waves, events, inst_total, stitched_total = [], [], 0, 0
        for wfile in sorted(u.glob('se0_sm0_sl*_wv*.json')):
            a = json.loads(wfile.read_text())
            wave = a['wave']
            assert a['duration'] == wave['end']-wave['begin']
            assert a['num_insts'] == a['num_stitched'], wfile
            events.extend([(wave['begin'],1),(wave['end'],-1)])
            inst_total += a['num_insts']
            stitched_total += a['num_stitched']
            waves.append(a['duration'])
            att_waves.append({'sid':r['sid'], 'layout':r['layout'], 'file':wfile.name,
                              'begin':wave['begin'],'end':wave['end'],'duration_cycles':a['duration'],
                              'num_insts':a['num_insts'],'num_stitched':a['num_stitched']})
        events.sort()
        occupied = peak = area = 0
        prev = events[0][0]
        for time,delta in events:
            area += (time-prev)*occupied
            occupied += delta
            peak = max(peak,occupied)
            prev = time
        assert occupied == 0 and area == sum(waves)
        span = events[-1][0]-events[0][0]
        # The steady loop executes K/32 times in each traced wave.
        loop_hits = len(waves)*r['shape'][2]//32
        loop = [x for x in rows if int(x['Hitcount']) == loop_hits]
        loop_ops = Counter(x['Instruction'].split()[0] for x in loop)
        for op,n in loop_ops.items():
            att_loops.append({'sid':r['sid'],'layout':r['layout'],'opcode':op,'per_wave_per_k32':n})
        (OUT/f"M{r['sid']}-{r['layout']}-loop.txt").write_text('\n'.join(
            f"{int(x['Vaddr']):08x}  {x['Instruction']}  // source: {x['Source']}" for x in loop)+'\n')
        before_first_wait = []
        for x in loop:
            if x['Instruction'].startswith('s_wait_loadcnt'):
                break
            if x['Instruction'].startswith('global_load_b128'):
                before_first_wait.append(x)
        target_ids = {x['CodeObj'] for x in rows if int(x['Hitcount'])}
        assert len(target_ids) == 1
        target = d/f'profile_gfx1200_code_object_id_{next(iter(target_ids))}.out'
        assert target.read_bytes() == (d/'kernel.hsaco').read_bytes()
        att_summary.append({'sid':r['sid'],'layout':r['layout'],'traced_waves':len(waves),
                             'median_wave_cycles':st.median(waves),'min_wave_cycles':min(waves),
                             'max_wave_cycles':max(waves),'target_simd_peak_resident_waves':peak,
                             'target_simd_mean_resident_waves':area/span,'trace_span_cycles':span,
                             'instructions':inst_total,'stitched':stitched_total,
                             'loop_decoded_instructions_per_k32':len(loop),
                             'loop_s_wait_dscnt':loop_ops['s_wait_dscnt'],
                             'global_loads_before_first_wait':len(before_first_wait),
                             'raw_target_matches_captured_elf':True,'ui_path':str(u.relative_to(ROOT))})
write_csv('att-instruction-summary.csv', att_groups)
write_csv('att-waves.csv', att_waves)
write_csv('att-summary.csv', att_summary)
write_csv('att-loop-counts.csv', att_loops)

checks = {'completed_jobs':len(kernels),'counter_dispatches':len({(x['job'],x['dispatch']) for x in counter_rows}),
          'att_dispatches':len(att_summary),'all_correctness_and_guard_checks_passed':True,
          'source_and_text_identical_across_profile_modes':True,
          'input_hashes_identical_across_profile_modes':True,
          'all_traced_instructions_stitched':True,
          'all_att_target_code_objects_equal_captured_compiler_output':True,
          'units':{'att':'decoder cycles, scoped to SE0 WGP1 SIMD0; costs may overlap between waves',
                   'FetchSize':'SDK-reported kilobytes; not a physical DRAM bandwidth measurement',
                   'SQC_LDS_BANK_CONFLICT':'SDK-defined emulated C1 event; summed bank-conflict cycles'}}
assert checks['completed_jobs'] == 36 and checks['counter_dispatches'] == 90
assert checks['att_dispatches'] == 6
assert set(identity) == {(sid, layout) for sid in range(3) for layout in ['default', 'linear']}
(OUT/'validation.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
print('ATT summaries:',json.dumps(att_summary,indent=2))
